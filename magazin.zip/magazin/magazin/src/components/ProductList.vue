<template>
  <div class="product">
    <span class="product-name">{{ product.name }}</span>
    <span class="product-price">{{ product.price }} руб.</span>
    <div v-if="isInCart" class="cart-controls">
      <button @click="decreaseQuantity" class="quantity-button">-</button>
      <input type="number" :value="cartItem.quantity" readonly class="quantity-input" />
      <button @click="increaseQuantity" class="quantity-button">+</button>
    </div>
    <button v-else @click="addToCart" class="add-button">Купить</button>
  </div>
</template>

<script>
export default {
  props: {
    product: Object,
  },
  computed: {
    isInCart() {
      return !!this.cartItem;
    },
    cartItem() {
      return this.$root.cart.find(item => item.product.id === this.product.id);
    }
  },
  methods: {
    addToCart() {
      this.$emit('add-to-cart', this.product);
    },
    increaseQuantity() {
      this.$emit('add-to-cart', this.product); // Reuse add-to-cart event
    },
    decreaseQuantity() {
      if (this.cartItem.quantity > 1) {
        this.$emit('decrease-quantity', this.product.id);
      } else {
        this.$emit('remove-item', this.product.id);
      }
    }
  }
};
</script>

<style>
.product-list {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}
</style>
